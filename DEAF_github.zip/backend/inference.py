import cv2
import numpy as np
from collections import deque
from .config import settings
from .model_loader import model_loader
import logging

logger = logging.getLogger(__name__)

class SignLanguagePipeline:
    def __init__(self):
        self.model = model_loader.model
        # Use a deque to store recent predictions for smoothing
        self.prediction_buffer = deque(maxlen=settings.PREDICTION_BUFFER_SIZE)
        self.current_confirmed_sign = None

    def process_frame(self, image_bytes: bytes) -> dict:
        """
        Processes a single frame: decodes, runs YOLO inference, tracks bounding boxes,
        applies confidence filtering, and smooths the sequence to output a stable sign.
        """
        # Decode image
        np_arr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

        if img is None:
            raise ValueError("Failed to decode image.")

        # Run YOLO inference
        results = self.model.predict(
            source=img,
            conf=settings.CONFIDENCE_THRESHOLD,
            iou=settings.IOU_THRESHOLD,
            verbose=False
        )

        detected_signs = []
        highest_conf_sign = None
        highest_conf = 0.0
        boxes_data = []

        # Parse results
        for result in results:
            boxes = result.boxes
            for box in boxes:
                conf = float(box.conf[0])
                cls = int(box.cls[0])
                name = result.names[cls]
                
                # Extract coordinates
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                
                detected_signs.append({
                    "class_id": cls,
                    "class_name": name,
                    "confidence": conf,
                    "box": [int(x1), int(y1), int(x2), int(y2)]
                })

                if conf > highest_conf:
                    highest_conf = conf
                    highest_conf_sign = name

        # Sequence/Gesture Smoothing (Simple majority vote/consecutive hits)
        stable_sign = None
        new_trigger = False
        
        if highest_conf_sign:
            self.prediction_buffer.append(highest_conf_sign)
        else:
            # If nothing detected, we can optionally clear buffer or append None
            self.prediction_buffer.append(None)

        # Check if the buffer is full and all elements are the same
        if len(self.prediction_buffer) == settings.PREDICTION_BUFFER_SIZE:
            # Check if all recent predictions match
            first_elem = self.prediction_buffer[0]
            if first_elem is not None and all(elem == first_elem for elem in self.prediction_buffer):
                stable_sign = first_elem
                # If this stable sign is different from the last confirmed one, it's a new trigger
                if stable_sign != self.current_confirmed_sign:
                    self.current_confirmed_sign = stable_sign
                    new_trigger = True
            elif first_elem is None and all(elem is None for elem in self.prediction_buffer):
                # Reset current sign if nothing is detected for a while
                self.current_confirmed_sign = None

        return {
            "detections": detected_signs,
            "raw_top_sign": highest_conf_sign,
            "stable_sign": stable_sign,
            "tts_trigger": new_trigger
        }
