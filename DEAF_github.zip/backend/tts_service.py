import pyttsx3
import asyncio
import threading
import logging
from .config import settings

logger = logging.getLogger(__name__)

class TTSService:
    """
    Asynchronous Text-to-Speech wrapper using pyttsx3.
    Runs the blocking pyttsx3 calls in a separate thread.
    """
    def __init__(self):
        self.engine = pyttsx3.init()
        self.engine.setProperty('rate', settings.TTS_RATE)
        self.engine.setProperty('volume', settings.TTS_VOLUME)
        # We need a lock to prevent multiple threads from accessing the engine simultaneously
        self.lock = threading.Lock()
        logger.info("TTS Service initialized.")

    def _speak_sync(self, text: str):
        """Synchronous blocking call to speak text."""
        with self.lock:
            try:
                self.engine.say(text)
                self.engine.runAndWait()
            except Exception as e:
                logger.error(f"TTS Engine error: {e}")

    async def speak(self, text: str):
        """
        Asynchronously speaks the given text.
        Converts stabilized words/phrases into vocal output without blocking the main event loop.
        """
        logger.info(f"Speaking text: '{text}'")
        loop = asyncio.get_running_loop()
        # Run the synchronous speak function in a thread pool
        await loop.run_in_executor(None, self._speak_sync, text)

# Global TTS service instance
tts_service = TTSService()
