from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class TranslationLogCreate(BaseModel):
    sign_detected: str
    confidence: float

class TranslationLogResponse(TranslationLogCreate):
    id: int
    timestamp: datetime

    class Config:
        from_attributes = True
