import asyncio
import websockets
import cv2
import json
import numpy as np

async def test_stream():
    uri = "ws://localhost:8000/ws/stream"
    
    try:
        async with websockets.connect(uri) as websocket:
            print("Connected to server.")
            
            # Open webcam
            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                print("Error: Could not open webcam.")
                return

            print("Starting video stream... Press 'q' in the video window to stop.")
            
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                    
                # Encode frame to JPEG
                _, buffer = cv2.imencode('.jpg', frame)
                image_bytes = buffer.tobytes()
                
                # Send frame
                await websocket.send(image_bytes)
                
                # Receive results
                response = await websocket.recv()
                result = json.loads(response)
                
                # Draw bounding boxes from raw detections
                if "detections" in result:
                    for det in result["detections"]:
                        box = det["box"] # [x1, y1, x2, y2]
                        conf = det["confidence"]
                        name = det["class_name"]
                        
                        # Draw rectangle around the hand/gesture
                        cv2.rectangle(frame, (box[0], box[1]), (box[2], box[3]), (0, 255, 0), 2)
                        
                        # Draw label above bounding box
                        label = f"{name} ({conf:.2f})"
                        cv2.putText(frame, label, (box[0], max(20, box[1] - 10)), 
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                
                # Draw the stable sign prominently in the top-left corner
                stable_sign = result.get("stable_sign")
                if stable_sign:
                    # Draw a dark background rectangle for text visibility
                    cv2.rectangle(frame, (10, 10), (400, 80), (0, 0, 0), -1)
                    
                    # Display the text of the recognized gesture
                    cv2.putText(frame, f"Gesture: {stable_sign.upper()}", (20, 60), 
                                cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 255, 255), 3)
                
                # Show the video feed on the screen
                cv2.imshow("Sign Language Translator", frame)
                
                # Check for 'q' key to quit
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                
                await asyncio.sleep(0.01)

    except Exception as e:
        print(f"Connection closed or error: {e}")
    finally:
        if 'cap' in locals():
            cap.release()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    asyncio.run(test_stream())
