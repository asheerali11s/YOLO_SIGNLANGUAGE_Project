from huggingface_hub import hf_hub_download

repo_id = "atalaydenknalbant/asl-yolo-models"
target_file = "yolov8s.pt"

print(f"Downloading {target_file} to models directory...")
try:
    model_path = hf_hub_download(repo_id=repo_id, filename=target_file, local_dir="models")
    print(f"Successfully downloaded to {model_path}")
except Exception as e:
    print(f"Error: {e}")
