import logging
import asyncio
from typing import List
from fastapi import FastAPI, UploadFile, File, HTTPException, WebSocket, WebSocketDisconnect, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import uvicorn

from .config import settings
from .inference import SignLanguagePipeline
from .tts_service import tts_service
from . import models, schemas, crud
from .database import engine, get_db, SessionLocal

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Create database tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Backend API with Database for Sign Language to Voice Translation"
)

# CORS setup
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize pipeline lazily on first request or startup
pipeline = None

@app.on_event("startup")
async def startup_event():
    global pipeline
    logger.info("Initializing Sign Language Pipeline...")
    pipeline = SignLanguagePipeline()
    logger.info("Application startup complete.")

@app.get("/")
async def health_check():
    return {"status": "ok", "message": "Sign Language API and Database are running"}

@app.get("/api/v1/history", response_model=List[schemas.TranslationLogResponse])
async def get_history(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    """Fetch the history of all translated signs from the database."""
    logs = crud.get_translation_logs(db, skip=skip, limit=limit)
    return logs

@app.post("/api/v1/process-frame")
async def process_frame(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """REST endpoint to process a single image frame."""
    if not file.content_type.startswith('image/'):
        raise HTTPException(status_code=400, detail="File provided is not an image.")

    try:
        image_bytes = await file.read()
        
        # Process the frame through YOLO and tracking logic
        result = pipeline.process_frame(image_bytes)
        
        # If a stable sign was newly detected, trigger TTS and save to DB
        if result["tts_trigger"] and result["stable_sign"]:
            # Trigger TTS asynchronously
            asyncio.create_task(tts_service.speak(result["stable_sign"]))
            
            # Save to Database
            log_data = schemas.TranslationLogCreate(
                sign_detected=result["stable_sign"],
                confidence=result["detections"][0]["confidence"] if result["detections"] else 0.0
            )
            crud.create_translation_log(db, log_data)
            
        return result
        
    except ValueError as ve:
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"Error processing frame: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.websocket("/ws/stream")
async def websocket_endpoint(websocket: WebSocket):
    """
    WebSocket endpoint for real-time continuous video streaming.
    Receives raw image bytes, processes them, saves to DB, and sends back JSON results.
    """
    await websocket.accept()
    logger.info("WebSocket connection established.")
    
    try:
        while True:
            # Receive binary frame from client
            image_bytes = await websocket.receive_bytes()
            
            # Process the frame
            result = pipeline.process_frame(image_bytes)
            
            # Trigger TTS and DB insertion if a new stable sign is recognized
            if result["tts_trigger"] and result["stable_sign"]:
                # TTS
                asyncio.create_task(tts_service.speak(result["stable_sign"]))
                
                # Database (using a temporary session since we don't have Depends in WS loop easily)
                db = SessionLocal()
                try:
                    log_data = schemas.TranslationLogCreate(
                        sign_detected=result["stable_sign"],
                        confidence=result["detections"][0]["confidence"] if result["detections"] else 0.0
                    )
                    crud.create_translation_log(db, log_data)
                finally:
                    db.close()
            
            # Send results back to client
            await websocket.send_json(result)
            
    except WebSocketDisconnect:
        logger.info("WebSocket connection closed by client.")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        try:
            await websocket.close()
        except:
            pass

if __name__ == "__main__":
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
