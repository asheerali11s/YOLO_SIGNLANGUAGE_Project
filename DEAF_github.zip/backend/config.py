import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # Application Configuration
    APP_NAME: str = "Sign Language to Voice API"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False

    # Paths
    BASE_DIR: str = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    MODEL_DIR: str = os.path.join(BASE_DIR, "models")
    YOLO_WEIGHTS_PATH: str = os.path.join(MODEL_DIR, "yolov8s.pt") 

    # Database
    DATABASE_URL: str = f"sqlite:///{os.path.join(BASE_DIR, 'deaf_app.db')}"

    # Inference Settings
    CONFIDENCE_THRESHOLD: float = 0.5
    IOU_THRESHOLD: float = 0.45
    
    # Smoothing Settings
    PREDICTION_BUFFER_SIZE: int = 5 
    
    # TTS Settings
    TTS_RATE: int = 150
    TTS_VOLUME: float = 1.0

    class Config:
        env_file = ".env"

settings = Settings()

# Ensure model directory exists
os.makedirs(settings.MODEL_DIR, exist_ok=True)
