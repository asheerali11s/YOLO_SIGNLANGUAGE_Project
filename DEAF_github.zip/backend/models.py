from sqlalchemy import Column, Integer, String, Float, DateTime
from sqlalchemy.sql import func
from .database import Base

class TranslationLog(Base):
    """
    Model to store a history of recognized sign language gestures.
    """
    __tablename__ = "translation_logs"

    id = Column(Integer, primary_key=True, index=True)
    sign_detected = Column(String, index=True)
    confidence = Column(Float)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
