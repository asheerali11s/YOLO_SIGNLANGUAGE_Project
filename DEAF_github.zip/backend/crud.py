from sqlalchemy.orm import Session
from . import models, schemas

def create_translation_log(db: Session, log: schemas.TranslationLogCreate):
    """Inserts a new recognized sign into the database."""
    db_log = models.TranslationLog(
        sign_detected=log.sign_detected,
        confidence=log.confidence
    )
    db.add(db_log)
    db.commit()
    db.refresh(db_log)
    return db_log

def get_translation_logs(db: Session, skip: int = 0, limit: int = 100):
    """Retrieves recent translation logs."""
    return db.query(models.TranslationLog).order_by(models.TranslationLog.timestamp.desc()).offset(skip).limit(limit).all()
