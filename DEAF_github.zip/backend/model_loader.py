import os
from ultralytics import YOLO
import logging
from .config import settings

logger = logging.getLogger(__name__)

class YOLOModelLoader:
    """
    Singleton class to load and cache the YOLO model.
    Ensures the model is only loaded into memory once.
    """
    _instance = None
    _model = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(YOLOModelLoader, cls).__new__(cls)
        return cls._instance

    def load_model(self):
        """Loads the YOLO model if it hasn't been loaded already."""
        if self._model is None:
            try:
                logger.info(f"Loading YOLO model from {settings.YOLO_WEIGHTS_PATH}")
                # Note: ultralytics will auto-download yolov8n.pt if it's the specified path and not found locally.
                self._model = YOLO(settings.YOLO_WEIGHTS_PATH)
                logger.info("YOLO model loaded successfully.")
            except Exception as e:
                logger.error(f"Failed to load YOLO model: {e}")
                raise e
        return self._model
    
    @property
    def model(self):
        """Returns the loaded model."""
        if self._model is None:
            return self.load_model()
        return self._model

# Instantiate singleton
model_loader = YOLOModelLoader()
